Notes:

The path for: ourmb_user.h is: /home/Desktop/scott/lkm-ourmb/ourmb_user.h
This path will need to be updated when copied to another machine. 

ourmb_user.h contains function prototypes for the 4 functions as well as macros.
